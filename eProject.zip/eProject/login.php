<?php
	session_start();
	 if($_REQUEST['usr']=="arya" && $_REQUEST["pswd"]=='lock'){
	 $_SESSION['usr'] = "arya";
	 $_SESSION['pswd'] = "lock";
	 header("Location: content.php");
	 }
	 else{
	 header("Location: ../index.php");
	 }
?>